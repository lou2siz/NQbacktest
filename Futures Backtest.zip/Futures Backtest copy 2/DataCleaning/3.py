import pandas as pd
import os
from datetime import datetime, time

# Get the directory of the current script
current_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the full paths to the CSV files
input_csv_path = os.path.join(current_dir, 'nq-5m-2.csv')
output_csv_path = os.path.join(current_dir, 'results.csv')

# Read the CSV file
data = pd.read_csv(input_csv_path, sep=';')

# Convert date and time columns to datetime
data['datetime'] = pd.to_datetime(data['date'] + ' ' + data['time'], format='%d/%m/%Y %H:%M')

# Function to process each day's XXX values
def process_day_xxx(group):
    valid_xxx = group[(group['datetime'].dt.time >= time(8, 0)) & 
                      (group['datetime'].dt.time < time(11, 0)) & 
                      (group['XXX'] != '')]
    
    if valid_xxx.empty:
        return None
    
    first_xxx_time = valid_xxx['datetime'].iloc[0].time()
    if time(8, 0) <= first_xxx_time < time(11, 0):
        xxx_values = valid_xxx['XXX'].astype(float)
        if 1.0 in xxx_values.values:
            return 1.0
        elif -1.0 in xxx_values.values:
            return -1.0
        else:
            return xxx_values.iloc[-1]  # Return the last value if neither 1.0 nor -1.0 is reached
    return None

# Group by date and process each day
results = data.groupby(data['datetime'].dt.date).apply(process_day_xxx).reset_index()
results.columns = ['Date', 'XXX']

# Remove rows with None values
results = results.dropna()

# Calculate the total sum
total_sum = results['XXX'].sum()

# Calculate the record
wins = (results['XXX'] == 1.0).sum()
losses = (results['XXX'] == -1.0).sum()
ties = len(results) - wins - losses

# Calculate the new adjustment
total_trades = wins + losses + ties
adjustment = total_trades * 0.0325

# Calculate the adjusted total sum
adjusted_total_sum = total_sum - adjustment

# Add a row with the total sum, record, and adjusted total sum
total_row = pd.DataFrame({
    'Date': ['Total'],
    'XXX': [total_sum],
    'Record': [f"{wins}-{losses}-{ties}"],
    'Adjusted Total': [adjusted_total_sum]
})
results['Record'] = ''  # Add empty Record column to results
results['Adjusted Total'] = ''  # Add empty Adjusted Total column to results
results = pd.concat([results, total_row], ignore_index=True)

# Save the results to a new CSV file
results.to_csv(output_csv_path, index=False)

print(f"Results processed and saved: {output_csv_path}")
print(f"Original total sum of XXX values: {total_sum}")
print(f"Record (W-L-T): {wins}-{losses}-{ties}")
print(f"Adjustment: {adjustment}")
print(f"Adjusted total sum of XXX values: {adjusted_total_sum}")