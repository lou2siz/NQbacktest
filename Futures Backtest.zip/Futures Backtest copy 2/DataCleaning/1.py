import pandas as pd
import pytz
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
# Read the CSV file
csv_path = os.path.join(current_dir, 'nq-5m.csv')
data = pd.read_csv(csv_path, sep=';', header=None, names=['date', 'time', 'open', 'high', 'low', 'close', 'volume'])


def round_to_nearest_quarter(value):
    if pd.notna(value) and isinstance(value, (int, float)):
        return round(value * 4) / 4
    return value

# Get the directory of the current script
current_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the full path to the CSV file
csv_path = os.path.join(current_dir, 'nq-5m.csv')

# Read the CSV file
data = pd.read_csv(csv_path, sep=';', header=None, names=['date', 'time', 'open', 'high', 'low', 'close', 'volume'])

# Remove the 'volume' column
data = data.drop(columns=['volume'])

# Apply rounding to 'open', 'high', 'low', 'close' columns
for col in ['open', 'high', 'low', 'close']:
    data[col] = data[col].apply(round_to_nearest_quarter)

data['date'] = data['date'].astype(str).fillna('')
data['time'] = data['time'].astype(str).fillna('')

try:
    data['datetime'] = pd.to_datetime(data['date'] + ' ' + data['time'], format='%d/%m/%Y %H:%M', errors='coerce')
except Exception as e:
    print(f"Error in datetime conversion: {e}")
data = data.dropna(subset=['datetime'])

data = data[data['datetime'] >= '2024-01-01']

data.sort_values(by='datetime', inplace=True)

print("Data after filtering, sorting, and rounding:")
print(data.head())
print(data.info())

try:
    central = pytz.timezone('US/Central')
    data['datetime'] = data['datetime'].dt.tz_localize(central, ambiguous='NaT')
except Exception as e:
    print(f"Error in timezone localization: {e}")

try:
    eastern = pytz.timezone('US/Eastern')
    data['datetime'] = data['datetime'].dt.tz_convert(eastern)
except Exception as e:
    print(f"Error in timezone conversion: {e}")

data['date'] = data['datetime'].dt.strftime('%d/%m/%Y')
data['time'] = data['datetime'].dt.strftime('%H:%M')
data = data.drop(columns=['datetime'])

# Save the modified data back to the same file
data.to_csv(csv_path, index=False, sep=';', header=False)

print(f"File processed and saved: {csv_path}")

