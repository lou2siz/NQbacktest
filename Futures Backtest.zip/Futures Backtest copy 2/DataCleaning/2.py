import pandas as pd
import os

def round_to_nearest_quarter(value):
    if pd.notna(value) and isinstance(value, (int, float)):
        return round(value * 4) / 4
    return value

def is_high_increasing(current, previous):
    return current > previous

def is_close_higher_than_open(row):
    return row['close'] > row['open']

def is_low_decreasing(current, previous):
    return current < previous

def is_close_lower_than_open(row):
    return row['close'] < row['open']

# Get the directory of the current script
current_dir = os.path.dirname(os.path.abspath(__file__))

# Construct the full path to the CSV file
csv_path = os.path.join(current_dir, 'nq-5m.csv')

# Read the CSV file
data = pd.read_csv(csv_path, sep=';', header=None, names=['date', 'time', 'open', 'high', 'low', 'close', 'volume'])

# Remove the 'volume' column
data = data.drop(columns=['volume'])

# Apply rounding to 'open', 'high', 'low', 'close' columns
for col in ['open', 'high', 'low', 'close']:
    data[col] = data[col].apply(round_to_nearest_quarter)

# Add new columns for conditions
condition_columns = ['GFVG', 'GFVGN', 'RFVG', 'RFVGN', 'GDP', 'RDP']
for col in condition_columns:
    data[col] = ''

# GFVG and GFVGN logic
for i in range(1, len(data) - 1):
    high_row_1 = data.loc[i - 1, 'high']
    low_row_3 = data.loc[i + 1, 'low']
    
    if high_row_1 < low_row_3:  # Check the GFVG condition
        data.loc[i, 'GFVG'] = 'GFVG'
        
        # Calculate the middle of the gap
        gap_middle = (high_row_1 + low_row_3) / 2
        data.loc[i, 'GFVGN'] = round_to_nearest_quarter(gap_middle)

# RFVG and RFVGN logic
for i in range(1, len(data) - 1):
    low_row_1 = data.loc[i - 1, 'low']
    high_row_3 = data.loc[i + 1, 'high']
    
    if low_row_1 > high_row_3:  # Check the RFVG condition
        data.loc[i, 'RFVG'] = 'RFVG'
        
        # Calculate the middle of the gap
        gap_middle = (low_row_1 + high_row_3) / 2
        data.loc[i, 'RFVGN'] = round_to_nearest_quarter(gap_middle)

# GDP logic
for i in range(2, len(data)):
    if (is_high_increasing(data.iloc[i-1]['high'], data.iloc[i-2]['high']) and
        is_high_increasing(data.iloc[i]['high'], data.iloc[i-1]['high']) and
        is_close_higher_than_open(data.iloc[i]) and
        is_close_higher_than_open(data.iloc[i-1]) and
        is_close_higher_than_open(data.iloc[i-2])):
        # Mark the current row as 'GDP'
        data.at[i, 'GDP'] = 'GDP'

# RDP logic
for i in range(2, len(data)):
    if (is_low_decreasing(data.iloc[i-1]['low'], data.iloc[i-2]['low']) and
        is_low_decreasing(data.iloc[i]['low'], data.iloc[i-1]['low']) and
        is_close_lower_than_open(data.iloc[i]) and
        is_close_lower_than_open(data.iloc[i-1]) and
        is_close_lower_than_open(data.iloc[i-2])):
        # Mark the current row as 'RDP'
        data.at[i, 'RDP'] = 'RDP'

# Reorder columns to group condition columns together
column_order = ['date', 'time', 'open', 'high', 'low', 'close'] + condition_columns

# Save the modified data back to the same file
data[column_order].to_csv(csv_path, index=False, sep=';', header=False)

print(f"File processed and saved with condition columns: {csv_path}")

