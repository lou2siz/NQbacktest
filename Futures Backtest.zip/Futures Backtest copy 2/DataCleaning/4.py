import pandas as pd
import numpy as np
from datetime import time, timedelta

def process_data(df):
    # Use the actual column names from your DataFrame
    df['date'] = pd.to_datetime(df.iloc[:, 0], format='%d/%m/%Y').dt.date
    df['time'] = pd.to_datetime(df.iloc[:, 1], format='%H:%M').dt.time
    df['datetime'] = pd.to_datetime(df['date'].astype(str) + ' ' + df['time'].astype(str))
    
    # Initialize new columns
    df['ONH'] = np.nan
    df['ONL'] = np.nan
    df['BHT'] = pd.NaT
    df['BLT'] = pd.NaT
    df['730BOS'] = ''
    df['DA'] = ''
    df['PA'] = ''
    df['X'] = ''
    df['XN'] = np.nan
    df['XXX'] = np.nan

    def process_day(group):
        # Reset values at the start of each day
        onh = onl = np.nan
        bht = blt = pd.NaT
        bos_730 = ''
        
        # Calculate ONH and ONL
        overnight_data = group[(group['time'] >= time(0, 0)) & (group['time'] <= time(5, 0))]
        if not overnight_data.empty:
            onh = overnight_data['high'].max()
            onl = overnight_data['low'].min()
        
        # Process each row
        for idx, row in group.iterrows():
            current_time = row['time']
            
            # Record ONH and ONL between 5:05 and 12:00
            if time(5, 5) <= current_time <= time(12, 0):
                group.at[idx, 'ONH'] = onh
                group.at[idx, 'ONL'] = onl
                
                # Check for BHT and BLT
                if pd.isna(bht) and row['high'] > onh:
                    bht = current_time
                if pd.isna(blt) and row['low'] < onl:
                    blt = current_time
            
            # Record BHT and BLT (now for all times after they're set)
            if not pd.isna(bht):
                group.at[idx, 'BHT'] = bht
            if not pd.isna(blt):
                group.at[idx, 'BLT'] = blt
            
            # Calculate 730BOS
            if not pd.isna(bht) and not pd.isna(blt):
                bos_730 = 'invalid'
            elif current_time >= time(7, 30):
                if not pd.isna(bht) and bht >= time(7, 30):
                    bos_730 = 'H'
                elif not pd.isna(blt) and blt >= time(7, 30):
                    bos_730 = 'L'
            group.at[idx, '730BOS'] = bos_730
            
            # Calculate DA and PA
            if idx > 0:
                prev_close = group.iloc[idx-1]['close']
                price_range = row['high'] - row['low']
                midpoint = row['low'] + price_range / 2
                if row['close'] <= midpoint:
                    group.at[idx, 'DA'] = 'DA'
                else:
                    group.at[idx, 'PA'] = 'PA'
            
            # Calculate X
            if bos_730 == 'H':
                gfvg_time = group.loc[:idx].iloc[::-1]['GFVG'].first_valid_index()
                if gfvg_time is not None and (idx - gfvg_time) <= 12:  # 60 minutes (assuming 5-minute intervals)
                    gdp_time = group.loc[gfvg_time:idx]['GDP'].first_valid_index()
                    if gdp_time is not None and (gdp_time - gfvg_time) <= 3:  # 15 minutes
                        group.at[idx, 'X'] = 'LONG'
            elif bos_730 == 'L':
                rfvg_time = group.loc[:idx].iloc[::-1]['RFVG'].first_valid_index()
                if rfvg_time is not None and (idx - rfvg_time) <= 12:  # 60 minutes
                    rdp_time = group.loc[rfvg_time:idx]['RDP'].first_valid_index()
                    if rdp_time is not None and (rdp_time - rfvg_time) <= 3:  # 15 minutes
                        group.at[idx, 'X'] = 'SHORT'
        
        # New XN column
        group['XN'] = ''
        for idx, row in group.iterrows():
            if pd.to_datetime(row['datetime']).time() >= pd.Timestamp('10:00').time() and pd.to_datetime(row['datetime']).time() < pd.Timestamp('11:00').time():
                if row['X'] == 'SHORT':
                    group.at[idx, 'XN'] = row['RFVGN']
                elif row['X'] == 'LONG':
                    group.at[idx, 'XN'] = row['GFVGN']

        # XXX column calculation
        group['XXX'] = ''
        xn_accessible = False
        xn_price = None
        start_time = None

        for idx, row in group.iterrows():
            current_time = pd.to_datetime(row['datetime'])
            
            if not xn_accessible and row['XN'] != '':
                if row['low'] <= float(row['XN']) <= row['high']:
                    xn_accessible = True
                    xn_price = float(row['XN'])
                    start_time = current_time
                    group.at[idx, 'XXX'] = 'START'

            if xn_accessible:
                price_diff = row['close'] - xn_price
                if row['X'] == 'SHORT':
                    if price_diff <= -40:
                        group.at[idx, 'XXX'] = 1
                        break
                    elif price_diff >= 40:
                        group.at[idx, 'XXX'] = -1
                        break
                elif row['X'] == 'LONG':
                    if price_diff >= 40:
                        group.at[idx, 'XXX'] = 1
                        break
                    elif price_diff <= -40:
                        group.at[idx, 'XXX'] = -1
                        break

                if current_time.time() == pd.Timestamp('16:00').time():
                    if row['X'] == 'SHORT':
                        group.at[idx, 'XXX'] = min(max(price_diff / 40, -1), 1)
                    elif row['X'] == 'LONG':
                        group.at[idx, 'XXX'] = min(max(price_diff / 40, -1), 1)
                    break

        return group

# Load the data
input_file = '/Users/lougoat/Desktop/Futures Backtest/DataCleaning/processed_nq-5m.csv'
output_file = '/Users/lougoat/Desktop/Futures Backtest/DataCleaning/xxnq-5m.csv'

# Read the CSV file
data = pd.read_csv(input_file, sep=',', header=0)

# Ensure column names are strings
data.columns = data.columns.astype(str)

# Create the datetime column correctly
data['datetime'] = pd.to_datetime(data['date'] + ' ' + data['time'], format='%d/%m/%Y %H:%M')

# Process the data by day
processed_data = data.groupby(data['datetime'].dt.date).apply(process_data).reset_index(drop=True)

# Remove duplicate columns
processed_data = processed_data.loc[:, ~processed_data.columns.duplicated()]

# Create 'XXX' column if it doesn't exist
if 'XXX' not in processed_data.columns:
    processed_data['XXX'] = 0  # Initialize with zeros or another appropriate default value

# Save the processed data
processed_data.to_csv(output_file, index=False)

# Calculate and print the sum of XXX
xxx_sum = processed_data['XXX'].sum()
print(f"Sum of XXX column: {xxx_sum}")

print(f"Processed data saved to: {output_file}")
