import os
import random
import logging
import pickle
from datetime import datetime, time

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from deap import base, creator, tools, algorithms
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Configure logging
logging.basicConfig(
    filename='ga_trading.log',
    filemode='a',
    format='%(asctime)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# ------------------------------
# Helper Functions
# ------------------------------
def round_to_nearest_quarter(value):
    if pd.notna(value) and isinstance(value, (int, float)):
        return round(value * 4) / 4
    return value

def is_high_increasing(current, previous):
    return current > previous

def is_close_higher_than_open(row):
    return row['close'] > row['open']

def is_low_decreasing(current, previous):
    return current < previous

def is_close_lower_than_open(row):
    return row['close'] < row['open']

def is_time_between(time_to_check, start_time, end_time):
    return start_time <= time_to_check <= end_time

def ensure_file_exists(file_path):
    if not os.path.exists(file_path):
        pd.DataFrame().to_csv(file_path, index=False)
    else:
        open(file_path, 'w').close()  # Clear the file if it exists

# ------------------------------
# Data Processing Functions
# ------------------------------
def compute_rsi(series, window=14):
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(window=window, min_periods=window).mean()
    avg_loss = loss.rolling(window=window, min_periods=window).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def compute_atr(df, window=14):
    high_low = df['high'] - df['low']
    high_close = (df['high'] - df['close'].shift()).abs()
    low_close = (df['low'] - df['close'].shift()).abs()
    ranges = pd.concat([high_low, high_close, low_close], axis=1)
    true_range = ranges.max(axis=1)
    atr = true_range.rolling(window=window).mean()
    return atr

def compute_mean_reversion(df, window=20, threshold=0.05):
    sma = df['close'].rolling(window=window).mean()
    deviation = (df['close'] - sma) / sma
    signal = deviation.abs() > threshold
    return signal.astype(int)

def compute_fvg(df):
    fvg = ((df['high'].shift(1) < df['low']) | (df['low'].shift(1) > df['high']))
    return fvg.astype(int)

def calculate_technical_indicators(df):
    """
    Calculate technical indicators and add them to the DataFrame.
    """
    df['RSI'] = compute_rsi(df['close'], window=14)
    df['EMA'] = df['close'].ewm(span=20, adjust=False).mean()
    df['SMA'] = df['close'].rolling(window=50).mean()
    df['ATR'] = compute_atr(df, window=14)
    df['Mean_Reversion'] = compute_mean_reversion(df)
    df['FVG'] = compute_fvg(df)
    return df

def process_initial_data(csv_path, output_csv_path, consecutive_candles_default=3):
    try:
        # Read the CSV file
        data = pd.read_csv(csv_path, sep=';', header=None, names=['date', 'time', 'open', 'high', 'low', 'close', 'volume'])
        logging.info("Initial data loaded.")
        
        # Remove the 'volume' column
        data = data.drop(columns=['volume'])
        
        # Apply rounding to 'open', 'high', 'low', 'close' columns
        for col in ['open', 'high', 'low', 'close']:
            data[col] = data[col].apply(round_to_nearest_quarter)
        
        # Add new columns for conditions
        condition_columns = ['GFVG', 'GFVGN', 'RFVG', 'RFVGN', 'GDP', 'RDP']
        for col in condition_columns:
            data[col] = ''
        
        # GFVG and RFVG logic
        for i in range(1, len(data) - 1):
            high_prev = data.loc[i - 1, 'high']
            low_next = data.loc[i + 1, 'low']
            if high_prev < low_next:
                data.at[i, 'GFVG'] = 'GFVG'
                gap_middle = (high_prev + low_next) / 2
                data.at[i, 'GFVGN'] = round_to_nearest_quarter(gap_middle)
            
            low_prev = data.loc[i - 1, 'low']
            high_next = data.loc[i + 1, 'high']
            if low_prev > high_next:
                data.at[i, 'RFVG'] = 'RFVG'
                gap_middle = (low_prev + high_next) / 2
                data.at[i, 'RFVGN'] = round_to_nearest_quarter(gap_middle)
        
        # GDP and RDP logic
        for i in range(consecutive_candles_default - 1, len(data)):
            # GDP logic
            gdp_condition = True
            for j in range(consecutive_candles_default - 1):
                if not (is_high_increasing(data.iloc[i - j]['high'], data.iloc[i - j - 1]['high']) and
                        is_close_higher_than_open(data.iloc[i - j])):
                    gdp_condition = False
                    break
            if gdp_condition:
                data.at[i, 'GDP'] = 'GDP'
            
            # RDP logic
            rdp_condition = True
            for j in range(consecutive_candles_default - 1):
                if not (is_low_decreasing(data.iloc[i - j]['low'], data.iloc[i - j - 1]['low']) and
                        is_close_lower_than_open(data.iloc[i - j])):
                    rdp_condition = False
                    break
            if rdp_condition:
                data.at[i, 'RDP'] = 'RDP'
        
        # Calculate technical indicators
        data = calculate_technical_indicators(data)
        
        # Reorder columns to group condition columns together
        column_order = ['date', 'time', 'open', 'high', 'low', 'close'] + condition_columns + ['RSI', 'EMA', 'SMA', 'ATR', 'Mean_Reversion', 'FVG']
        data = data[column_order]
        
        # Save the modified data to the output file
        data.to_csv(output_csv_path, index=False, sep=';', header=False)
        logging.info(f"Initial data processed and saved to {output_csv_path}.")
    except Exception as e:
        logging.error(f"Error in process_initial_data: {e}")

def process_strategy_data(input_csv_path, output_csv_path, consecutive_candles_default=3, da_pa_split_default=50,
                         rsi_period=14, rsi_overbought=70, rsi_oversold=30,
                         ema_period=20, sma_period=50,
                         atr_period=14, atr_multiplier=1.5):
    try:
        # Ensure output file exists and is empty
        ensure_file_exists(output_csv_path)
        
        # Read the CSV file
        data = pd.read_csv(input_csv_path, sep=';', names=['date', 'time', 'open', 'high', 'low', 'close',
                                                          'GFVG', 'GFVGN', 'RFVG', 'RFVGN', 'GDP', 'RDP',
                                                          'RSI', 'EMA', 'SMA', 'ATR', 'Mean_Reversion', 'FVG'])
        logging.info("Strategy data loaded.")
        
        # Convert date and time columns to datetime
        data['datetime'] = pd.to_datetime(data['date'] + ' ' + data['time'], format='%d/%m/%Y %H:%M')
        
        # Initialize new columns
        new_columns = ['ONH', 'ONL', 'BHT', 'BLT', '730BOS', 'DA_PA', 'X', 'XN', 'XXX']
        for col in new_columns:
            data[col] = ''
        
        # Process data day by day
        for date, group in data.groupby(data['datetime'].dt.date):
            overnight_data = group[(group['datetime'].dt.time >= time(0, 0)) &
                                   (group['datetime'].dt.time < time(5, 0))]
            overnight_high = overnight_data['high'].max()
            overnight_low = overnight_data['low'].min()
            
            bht = blt = None
            previous_close = None
            active_x_type = None
            active_x_value = None
            xxx_position_opened = False
            xxx_value = None
            xxx_entry_price = None
            onh_value = onl_value = None
            
            for idx, row in group.iterrows():
                current_time = row['datetime'].time()
                
                # Reset values at 00:00
                if current_time == time(0, 0):
                    bht = blt = None
                    active_x_type = None
                    active_x_value = None
                    xxx_position_opened = False
                    xxx_value = None
                    xxx_entry_price = None
                    onh_value = onl_value = None
                    data.at[idx, '730BOS'] = ''
                
                # Calculate ONH and ONL
                if time(5, 5) <= current_time < time(12, 0):
                    if onh_value is None and row['high'] > overnight_high:
                        onh_value = row['high']
                    if onl_value is None and row['low'] < overnight_low:
                        onl_value = row['low']
                
                # Set ONH and ONL values for each row
                data.at[idx, 'ONH'] = onh_value if onh_value is not None else ''
                data.at[idx, 'ONL'] = onl_value if onl_value is not None else ''
                
                # Update BLT and BHT
                if time(5, 5) <= current_time < time(12, 0):
                    if onh_value is not None and row['high'] > onh_value:
                        bht = current_time
                    if onl_value is not None and row['low'] < onl_value:
                        blt = current_time
                
                # Set BLT and BHT values for each row
                data.at[idx, 'BLT'] = bht.strftime('%H:%M') if bht else ''
                data.at[idx, 'BHT'] = bht.strftime('%H:%M') if bht else ''
                
                # Calculate 730BOS
                if current_time >= time(7, 30):
                    if bht and blt:
                        data.at[idx, '730BOS'] = 'invalid'
                    elif bht and bht >= time(7, 30):
                        data.at[idx, '730BOS'] = 'H'
                    elif blt and blt >= time(7, 30):
                        data.at[idx, '730BOS'] = 'L'
                    elif idx > 0:
                        data.at[idx, '730BOS'] = data.at[idx - 1, '730BOS']
                    else:
                        data.at[idx, '730BOS'] = ''
                else:
                    data.at[idx, '730BOS'] = ''
                
                # Calculate DA and PA
                da_pa_split = da_pa_split_default
                if previous_close is not None:
                    price_range = row['high'] - row['low']
                    split_point = row['low'] + (price_range * da_pa_split / 100)
                    if row['close'] <= split_point:
                        data.at[idx, 'DA_PA'] = 'DA'
                    else:
                        data.at[idx, 'DA_PA'] = 'PA'
                else:
                    data.at[idx, 'DA_PA'] = ''
                previous_close = row['close']
                
                # Calculate X and XN
                is_display_time = time(10, 0) <= current_time < time(11, 0)
                is_trading_time = time(10, 0) <= current_time < time(16, 0)
                if is_trading_time:
                    if data.at[idx, '730BOS'] == 'H':
                        rfvg_condition = data.loc[max(idx - 12, 0):idx, 'RFVG'].eq('RFVG').any()
                        if rfvg_condition:
                            rfvg_index = data.loc[max(idx - 12, 0):idx, 'RFVG'].eq('RFVG').idxmax()
                            rdp_condition = data.loc[max(rfvg_index - 3, 0):min(rfvg_index + 3, idx), 'RDP'].eq('RDP').any()
                            if rdp_condition:
                                active_x_type = 'SHORT'
                                active_x_value = data.at[rfvg_index, 'RFVGN']
                    elif data.at[idx, '730BOS'] == 'L':
                        gfvg_condition = data.loc[max(idx - 12, 0):idx, 'GFVG'].eq('GFVG').any()
                        if gfvg_condition:
                            gfvg_index = data.loc[max(idx - 12, 0):idx, 'GFVG'].eq('GFVG').idxmax()
                            gdp_condition = data.loc[max(gfvg_index - 3, 0):min(gfvg_index + 3, idx), 'GDP'].eq('GDP').any()
                            if gdp_condition:
                                active_x_type = 'LONG'
                                active_x_value = data.at[gfvg_index, 'GFVGN']
                    
                    # Only display X and XN between 10:00 and 11:00
                    if is_display_time:
                        data.at[idx, 'X'] = active_x_type if active_x_type else ''
                        data.at[idx, 'XN'] = active_x_value if active_x_value else ''
                    else:
                        data.at[idx, 'X'] = ''
                        data.at[idx, 'XN'] = ''
                else:
                    data.at[idx, 'X'] = ''
                    data.at[idx, 'XN'] = ''
                
                # Calculate XXX using active_x_type and active_x_value
                if not xxx_position_opened and active_x_type and active_x_value:
                    try:
                        xn_value = float(active_x_value)
                        if row['low'] <= xn_value <= row['high']:
                            xxx_entry_price = xn_value
                            xxx_position_opened = True
                    except ValueError:
                        logging.warning(f"Invalid XN value at index {idx}: {active_x_value}")
                
                if xxx_position_opened and current_time < time(16, 0) and (xxx_value is None or (-1.0 < xxx_value < 1.0)):
                    price_diff = row['close'] - xxx_entry_price
                    if active_x_type == 'SHORT':
                        if price_diff <= -atr_multiplier * row['ATR']:
                            xxx_value = 1.0
                        elif price_diff >= atr_multiplier * row['ATR']:
                            xxx_value = -1.0
                        else:
                            xxx_value = round(-1 * (price_diff / (atr_multiplier * row['ATR'])), 2)
                    elif active_x_type == 'LONG':
                        if price_diff >= atr_multiplier * row['ATR']:
                            xxx_value = 1.0
                        elif price_diff <= -atr_multiplier * row['ATR']:
                            xxx_value = -1.0
                        else:
                            xxx_value = round(price_diff / (atr_multiplier * row['ATR']), 2)
                    data.at[idx, 'XXX'] = xxx_value if xxx_value is not None else ''
                
                # Reset XXX calculation at 16:00
                if current_time >= time(16, 0):
                    xxx_position_opened = False
                    xxx_value = None
                    xxx_entry_price = None
        
        # Save the modified data to the new file
        data.to_csv(output_csv_path, index=False, sep=';')
        logging.info(f"Strategy processing completed and saved to {output_csv_path}.")
    except KeyError as ke:
        logging.error(f"KeyError in process_strategy_data: {ke}")
    except Exception as e:
        logging.error(f"Error in process_strategy_data: {e}")

def calculate_monthly_returns(input_csv_path, output_csv_path):
    try:
        # Read the CSV file
        data = pd.read_csv(input_csv_path, sep=';')
        
        # Convert date and time columns to datetime
        data['datetime'] = pd.to_datetime(data['date'] + ' ' + data['time'], format='%d/%m/%Y %H:%M')
        
        # Initialize a list to store monthly returns
        monthly_returns = []
        
        # Group by month
        data['month'] = data['datetime'].dt.to_period('M')
        for month, group in data.groupby('month'):
            group = group.copy()
            group['XXX'] = pd.to_numeric(group['XXX'], errors='coerce').fillna(0)
            total_return = group['XXX'].sum()
            win_trades = (group['XXX'] == 1.0).sum()
            loss_trades = (group['XXX'] == -1.0).sum()
            win_percentage = ((win_trades - loss_trades) / (win_trades + loss_trades + 1e-6)) * 100 if (win_trades + loss_trades) > 0 else 0
            monthly_returns.append({
                'Month': str(month),
                'Total_Return': total_return,
                'Win_Trades': win_trades,
                'Loss_Trades': loss_trades,
                'Win_Percentage': win_percentage
            })
        
        # Create a DataFrame for monthly returns
        monthly_returns_df = pd.DataFrame(monthly_returns)
        
        # Save to CSV
        monthly_returns_df.to_csv(output_csv_path, index=False)
        logging.info(f"Monthly returns calculated and saved to {output_csv_path}.")
    except KeyError as ke:
        logging.error(f"KeyError in calculate_monthly_returns: {ke}")
    except Exception as e:
        logging.error(f"Error in calculate_monthly_returns: {e}")

# ------------------------------
# Genetic Algorithm Functions
# ------------------------------
def evaluate_strategy(individual, data, risk_params):
    """
    Evaluate the strategy based on the individual's parameters.
    Parameters:
    - individual: A list containing strategy parameters.
    - data: The DataFrame containing strategy data.
    - risk_params: Dictionary containing risk simulation parameters.
    Returns:
    - A tuple with the fitness score.
    """
    try:
        (consecutive_candles, da_pa_split,
         rsi_period, rsi_overbought, rsi_oversold,
         ema_period, sma_period,
         atr_period, atr_multiplier) = individual
        
        # Ensure parameters are within realistic bounds
        if not (2 <= consecutive_candles <= 10 and
                30 <= da_pa_split <= 70 and
                5 <= rsi_period <= 30 and
                50 <= rsi_overbought <= 80 and
                20 <= rsi_oversold <= 50 and
                10 <= ema_period <= 50 and
                20 <= sma_period <= 100 and
                10 <= atr_period <= 30 and
                1.0 <= atr_multiplier <= 3.0):
            return (-1e6,)
        
        # Copy data to avoid modifying original
        df = data.copy()
        
        # Recalculate technical indicators based on individual's parameters
        df['RSI'] = compute_rsi(df['close'], window=int(rsi_period))
        df['EMA'] = df['close'].ewm(span=int(ema_period), adjust=False).mean()
        df['SMA'] = df['close'].rolling(window=int(sma_period)).mean()
        df['ATR'] = compute_atr(df, window=int(atr_period))
        df['Mean_Reversion'] = compute_mean_reversion(df, window=int(consecutive_candles), threshold=0.05)
        df['FVG'] = compute_fvg(df)  # Placeholder
        
        # Strategy Implementation
        df['Signal'] = 0
        df.loc[
            (df['DA_PA'] == 'PA') &
            (df['RSI'] > rsi_overbought) &
            (df['EMA'] > df['SMA']),
            'Signal'] = 1  # Buy Signal
        
        df.loc[
            (df['DA_PA'] == 'DA') &
            (df['RSI'] < rsi_oversold) &
            (df['EMA'] < df['SMA']),
            'Signal'] = -1  # Sell Signal
        
        # Entry Conditions based on FVG
        df['Entry'] = df['FVG'] * df['Signal']
        
        # Exit Conditions based on ATR
        df['Exit'] = 0
        df.loc[df['ATR'] > atr_multiplier, 'Exit'] = 1  # Example condition
        
        # Combine Signals
        df['Combined_Signal'] = df['Entry'] * df['Exit']
        
        # Calculate Returns with Risk Simulation
        df['Returns'] = df['Combined_Signal'].shift(1) * df['close'].pct_change()
        df['Strategy_Returns'] = df['Returns'].fillna(0)
        
        # Apply transaction costs and slippage
        df['Strategy_Returns'] -= risk_params['transaction_cost'] * df['Combined_Signal'].abs()
        df['Strategy_Returns'] -= risk_params['slippage'] * df['close'].pct_change().abs()
        
        # Calculate Performance Metrics
        total_return = df['Strategy_Returns'].sum()
        wins = (df['Strategy_Returns'] > 0).sum()
        losses = (df['Strategy_Returns'] < 0).sum()
        win_surplus = wins - losses  # Aim for at least 8 surplus
        win_percentage = (wins / (wins + losses + 1e-6)) * 100  # Avoid division by zero
        
        # Risk-Adjusted Return (Sharpe Ratio)
        sharpe_ratio = df['Strategy_Returns'].mean() / df['Strategy_Returns'].std() * np.sqrt(252) if df['Strategy_Returns'].std() != 0 else 0
        
        # Maximum Drawdown
        cumulative = (1 + df['Strategy_Returns']).cumprod()
        peak = cumulative.expanding(min_periods=1).max()
        drawdown = (cumulative - peak) / peak
        max_drawdown = drawdown.min()
        
        # Fitness Function: Combine multiple metrics
        fitness = total_return + sharpe_ratio * 2 + win_surplus * 5  # Weighted sum
        
        # Prioritize strategies with at least 8% win surplus
        if win_surplus < 8:
            fitness -= (8 - win_surplus) * 10  # Penalize if below target
        
        # Additional penalty for high drawdown
        fitness -= abs(max_drawdown) * 100  # Heavily penalize high drawdown
        
        # Enforce constraints
        if total_return < 1.0 or max_drawdown < -0.50:
            fitness -= 1e6  # Heavily penalize if constraints are not met
        
        return (fitness,)
    except Exception as e:
        logging.error(f"Error in evaluate_strategy: {e}")
        return (-1e6,)

def setup_genetic_algorithm():
    """
    Setup the genetic algorithm using DEAP.
    Returns:
    - toolbox: The DEAP toolbox with all necessary registrations.
    """
    # Avoid re-defining creator
    try:
        creator.create("FitnessMax", base.Fitness, weights=(1.0,))  # We aim to maximize the fitness
        creator.create("Individual", list, fitness=creator.FitnessMax)
    except AttributeError:
        pass  # Already created
    
    toolbox = base.Toolbox()
    
    # Attribute generators
    toolbox.register("consecutive_candles", random.randint, 2, 10)
    toolbox.register("da_pa_split", random.uniform, 30, 70)
    toolbox.register("rsi_period", random.randint, 5, 30)
    toolbox.register("rsi_overbought", random.uniform, 50, 80)
    toolbox.register("rsi_oversold", random.uniform, 20, 50)
    toolbox.register("ema_period", random.randint, 10, 50)
    toolbox.register("sma_period", random.randint, 20, 100)
    toolbox.register("atr_period", random.randint, 10, 30)
    toolbox.register("atr_multiplier", random.uniform, 1.0, 3.0)
    
    # Structure initializers
    toolbox.register("individual", tools.initCycle, creator.Individual,
                     (toolbox.consecutive_candles,
                      toolbox.da_pa_split,
                      toolbox.rsi_period,
                      toolbox.rsi_overbought,
                      toolbox.rsi_oversold,
                      toolbox.ema_period,
                      toolbox.sma_period,
                      toolbox.atr_period,
                      toolbox.atr_multiplier), n=1)
    
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)
    
    # Genetic operators
    toolbox.register("mate", tools.cxTwoPoint)
    toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=1, indpb=0.2)
    toolbox.register("select", tools.selTournament, tournsize=3)
    
    return toolbox

def elite_selection(population, k):
    """
    Select elite individuals based on fitness.
    """
    return tools.selBest(population, k)

def advanced_mutation(individual, toolbox):
    """
    Perform advanced mutations focusing on ensemble indicators.
    """
    # Mutate EMA and SMA together
    if random.random() < 0.5:
        individual[5] += int(random.gauss(0, 2))  # ema_period
        individual[6] += int(random.gauss(0, 2))  # sma_period
    
    # Mutate RSI parameters together
    if random.random() < 0.5:
        individual[2] += int(random.gauss(0, 1))    # rsi_period
        individual[3] += random.gauss(0, 2)         # rsi_overbought
        individual[4] += random.gauss(0, 2)         # rsi_oversold
    
    # Mutate ATR parameters together
    if random.random() < 0.5:
        individual[7] += int(random.gauss(0, 1))    # atr_period
        individual[8] += random.gauss(0, 0.1)       # atr_multiplier
    
    # Ensure parameters stay within bounds after mutation
    individual[0] = max(2, min(10, individual[0]))
    individual[1] = max(30, min(70, individual[1]))
    individual[2] = max(5, min(30, individual[2]))
    individual[3] = max(50, min(80, individual[3]))
    individual[4] = max(20, min(50, individual[4]))
    individual[5] = max(10, min(50, individual[5]))
    individual[6] = max(20, min(100, individual[6]))
    individual[7] = max(10, min(30, individual[7]))
    individual[8] = max(1.0, min(3.0, individual[8]))
    
    return (individual,)

# ------------------------------
# Monte Carlo Tree Search Integration
# ------------------------------
class MCTSNode:
    def __init__(self, state, parent=None):
        self.state = state  # Current strategy parameters
        self.parent = parent
        self.children = []
        self.visits = 0
        self.reward = 0.0

    def is_fully_expanded(self):
        # Define expansion criteria
        return len(self.children) >= 4  # Arbitrary number of possible mutations

    def best_child(self, c_param=1.4):
        choices_weights = [
            (child.reward / child.visits) + c_param * np.sqrt((2 * np.log(self.visits) / child.visits))
            for child in self.children
        ]
        return self.children[np.argmax(choices_weights)]

def mcts(root, iterations, evaluate_func, data, risk_params):
    for _ in range(iterations):
        node = root
        # Selection
        while node.is_fully_expanded() and node.children:
            node = node.best_child()
        # Expansion
        if not node.is_fully_expanded():
            # Expand a new child
            new_params = mutate_strategy(node.state)
            child_node = MCTSNode(new_params, parent=node)
            node.children.append(child_node)
            node = child_node
        # Simulation
        reward = evaluate_func(node.state, data, risk_params)[0]
        # Backpropagation
        while node is not None:
            node.visits += 1
            node.reward += reward
            node = node.parent
    # Return the best child
    return root.best_child(c_param=0)

def mutate_strategy(strategy):
    # Simple mutation: randomly adjust one parameter
    new_strategy = strategy.copy()
    param_to_mutate = random.randint(0, len(strategy) - 1)
    if isinstance(strategy[param_to_mutate], int):
        new_strategy[param_to_mutate] += random.choice([-1, 1])
    else:
        new_strategy[param_to_mutate] += random.uniform(-0.5, 0.5)
    return new_strategy

def integrate_mcts(population, toolbox, evaluate_func, data, risk_params, mcts_iterations=10):
    new_population = []
    for individual in population:
        root = MCTSNode(individual)
        best_child = mcts(root, mcts_iterations, evaluate_func, data, risk_params)
        new_population.append(best_child.state)
    return new_population

def apply_machine_learning(population, data, labels):
    """
    Apply a machine learning model to predict profitable strategies.
    """
    try:
        X = pd.DataFrame(population)
        y = labels
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        clf = RandomForestClassifier(n_estimators=100, random_state=42)
        clf.fit(X_train, y_train)
        predictions = clf.predict(X_test)
        accuracy = accuracy_score(y_test, predictions)
        logging.info(f"Machine Learning Model Accuracy: {accuracy * 100:.2f}%")
        return clf
    except Exception as e:
        logging.error(f"Error in apply_machine_learning: {e}")
        return None

def main():
    try:
        # Get the directory of the current script
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Define file paths
        initial_csv_path = os.path.join(current_dir, 'nq-5m.csv')
        processed_initial_csv = os.path.join(current_dir, 'nq-5m-processed.csv')
        strategy_processed_csv = os.path.join(current_dir, 'nq-5m-strategy.csv')
        monthly_returns_csv = os.path.join(current_dir, 'monthly_returns.csv')
        top_strategies_dir = os.path.join(current_dir, 'project_folder')
        os.makedirs(top_strategies_dir, exist_ok=True)
        
        # Risk Simulation Parameters
        risk_params = {
            'transaction_cost': 0.0025,  # 0.25%
            'slippage': 0.001             # 0.1%
        }
        
        # Step 1: Process Initial Data
        process_initial_data(initial_csv_path, processed_initial_csv)
        
        # Step 2: Process Strategy Data
        process_strategy_data(processed_initial_csv, strategy_processed_csv)
        
        # Step 3: Read Strategy Processed Data for GA
        data = pd.read_csv(strategy_processed_csv, sep=';')
        
        # Initialize Genetic Algorithm components
        toolbox = setup_genetic_algorithm()
        
        # Initialize population
        population = toolbox.population(n=50)
        
        # Define the number of generations
        NGEN = 100
        
        # Define the probability of crossover
        CXPB = 0.7
        
        # Define the probability of mutation
        MUTPB = 0.3
        
        # Define the number of elites
        NELITE = 5
        
        # Initialize statistics
        stats = tools.Statistics(lambda ind: ind.fitness.values)
        stats.register("avg", np.mean)
        stats.register("std", np.std)
        stats.register("min", np.min)
        stats.register("max", np.max)
        
        # Hall of Fame to store top individuals
        hof = tools.HallOfFame(10)
        
        logging.info("Starting Genetic Algorithm optimization...")
        
        # Open a CSV file to log generation statistics
        gen_stats_path = os.path.join(current_dir, 'generation_stats.csv')
        with open(gen_stats_path, 'w') as f:
            f.write('Generation,Average_Fitness,Max_Fitness,Min_Fitness\n')
        
        # Genetic Algorithm Loop
        for gen in range(NGEN):
            logging.info(f"-- Generation {gen} --")
            
            # Evaluate fitness of individuals
            invalid_ind = [ind for ind in population if not ind.fitness.valid]
            for ind in invalid_ind:
                ind.fitness.values = evaluate_strategy(ind, data, risk_params)
            
            # Update Hall of Fame
            hof.update(population)
            
            # Gather statistics
            record = stats.compile(population)
            logging.info(f"Stats: {record}")
            
            # Log generation statistics to CSV
            with open(gen_stats_path, 'a') as f:
                f.write(f"{gen},{record['avg']},{record['max']},{record['min']}\n")
            
            # Check for stopping condition: average fitness negative
            if record['avg'] < 0:
                logging.warning("Average fitness negative. Stopping GA.")
                break
            
            # Select elites
            elites = elite_selection(population, NELITE)
            
            # Generate offspring from elites
            offspring = []
            while len(offspring) < len(population):
                parents = random.sample(elites, 2)
                child1, child2 = toolbox.mate(parents[0], parents[1])
                del child1.fitness.values
                del child2.fitness.values
                offspring.extend([child1, child2])
            
            # Truncate to population size
            offspring = offspring[:len(population)]
            
            # Apply advanced mutations to offspring
            for mutant in offspring:
                if random.random() < MUTPB:
                    mutant, = advanced_mutation(mutant, toolbox)
                    del mutant.fitness.values  # Invalidate fitness
            
            # Replace the old population with the new offspring
            population[:] = offspring
            
            # Optional: Save population state every 10 generations
            if gen % 10 == 0 and gen != 0:
                pop_path = os.path.join(current_dir, f'population_gen_{gen}.pkl')
                with open(pop_path, 'wb') as f_pop:
                    pickle.dump(population, f_pop)
                logging.info(f"Population at generation {gen} saved to {pop_path}.")
        
        # Select the best individuals
        best_individuals = tools.selBest(population, 10)
        
        # Save top strategies' rules to text files
        for idx, ind in enumerate(best_individuals):
            strategy_rules = f"""
            Strategy {idx + 1}:
            Consecutive Candles: {int(ind[0])}
            DA_PA Split: {ind[1]:.2f}
            RSI Period: {int(ind[2])}
            RSI Overbought Threshold: {ind[3]:.2f}
            RSI Oversold Threshold: {ind[4]:.2f}
            EMA Period: {int(ind[5])}
            SMA Period: {int(ind[6])}
            ATR Period: {int(ind[7])}
            ATR Multiplier: {ind[8]:.2f}
            Total Return: {ind.fitness.values[0]:.2f}
            """
            strategy_folder = os.path.join(top_strategies_dir, f'strategy_{idx + 1}')
            os.makedirs(strategy_folder, exist_ok=True)
            
            # Save strategy rules
            with open(os.path.join(strategy_folder, 'strategy_rules.txt'), 'w') as f:
                f.write(strategy_rules)
            
            # Save related CSV data
            optimized_strategy_csv = os.path.join(strategy_folder, f'nq-5m-strategy_optimized_{idx + 1}.csv')
            process_strategy_data(
                processed_initial_csv,
                optimized_strategy_csv,
                consecutive_candles_default=int(ind[0]),
                da_pa_split_default=ind[1],
                rsi_period=int(ind[2]),
                rsi_overbought=ind[3],
                rsi_oversold=ind[4],
                ema_period=int(ind[5]),
                sma_period=int(ind[6]),
                atr_period=int(ind[7]),
                atr_multiplier=ind[8]
            )
            
            # Calculate Monthly Returns
            optimized_monthly_returns_csv = os.path.join(strategy_folder, f'monthly_returns_{idx + 1}.csv')
            calculate_monthly_returns(optimized_strategy_csv, optimized_monthly_returns_csv)
            
            # Save strategy parameters
            with open(os.path.join(strategy_folder, 'parameters.pkl'), 'wb') as f_param:
                pickle.dump(ind, f_param)
        
        # Save top strategies to pickle for future use
        with open(os.path.join(top_strategies_dir, 'best_strategies.pkl'), 'wb') as f:
            pickle.dump(best_individuals, f)
        
        # Save Hall of Fame
        with open(os.path.join(top_strategies_dir, 'hall_of_fame.pkl'), 'wb') as f:
            pickle.dump(hof, f)
        
        logging.info("Saving generation statistics and best strategies.")
        
        # Step 4: Apply Optimized Parameters to Strategy and Calculate Monthly Returns
        # Already handled in the loop above
        
        # Step 5: Output Additional Data
        # Example: Save cumulative returns plot for top strategies
        for idx, strategy_folder in enumerate(os.listdir(top_strategies_dir)):
            strategy_path = os.path.join(top_strategies_dir, strategy_folder)
            strategy_csv = os.path.join(strategy_path, f'nq-5m-strategy_optimized_{idx + 1}.csv')
            if os.path.exists(strategy_csv):
                df = pd.read_csv(strategy_csv, sep=';')
                df['Strategy_Returns'] = pd.to_numeric(df['XXX'], errors='coerce').fillna(0)
                df['Cumulative_Returns'] = (1 + df['Strategy_Returns']).cumprod()
                
                plt.figure(figsize=(10, 6))
                plt.plot(df['datetime'], df['Cumulative_Returns'], label=f'Strategy {idx + 1}')
                plt.xlabel('Date')
                plt.ylabel('Cumulative Returns')
                plt.title(f'Cumulative Returns for Strategy {idx + 1}')
                plt.legend()
                plt.grid(True)
                plt.tight_layout()
                plt.savefig(os.path.join(strategy_path, f'cumulative_returns_{idx + 1}.png'))
                plt.close()
        
        logging.info("Optimization and data export completed.")
        
    except Exception as e:
        logging.error(f"Error in main: {e}")

if __name__ == "__main__":
    main()
